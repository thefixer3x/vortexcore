
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/ai-router-proxy.mts
var ai_router_proxy_default = async (req, _context) => {
  const supabaseUrl = process.env.VITE_SUPABASE_URL || "https://mxtsdgkwzjzlttpotole.supabase.co";
  const anonKey = process.env.VITE_SUPABASE_ANON_KEY;
  const endpoint = `${supabaseUrl}/functions/v1/ai-router`;
  const init = {
    method: "POST",
    headers: {
      "content-type": "application/json",
      ...anonKey ? { apikey: anonKey } : {},
      // Forward auth if present
      ...req.headers.get("authorization") ? { authorization: req.headers.get("authorization") } : {}
    },
    body: await req.text()
  };
  const resp = await fetch(endpoint, init);
  const body = await resp.text();
  return new Response(body, { status: resp.status, headers: { "content-type": resp.headers.get("content-type") || "application/json" } });
};
var config = {
  path: "/api/ai-router"
};
export {
  config,
  ai_router_proxy_default as default
};
