
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/health.mts
var health_default = async (_req, _context) => {
  return new Response(
    JSON.stringify({ ok: true, service: "vortexcore", time: (/* @__PURE__ */ new Date()).toISOString() }),
    { headers: { "content-type": "application/json" } }
  );
};
var config = {
  path: "/health"
};
export {
  config,
  health_default as default
};
